const express = require('express');
const { body } = require('express-validator');
const authController = require('../controllers/authController');
const validate = require('../middleware/validate');
const { loginLimiter } = require('../middleware/rateLimiter');
const csrfOriginCheck = require('../middleware/csrfOriginCheck');

const router = express.Router();

router.post(
  '/user/login',
  loginLimiter,
  [
    body('loginId').trim().notEmpty().withMessage('User ID is required'),
    body('password').notEmpty().withMessage('Password is required'),
  ],
  validate,
  authController.userLogin
);

router.post(
  '/admin/login',
  loginLimiter,
  [
    body('loginId').trim().notEmpty().withMessage('Admin ID is required'),
    body('password').notEmpty().withMessage('Password is required'),
  ],
  validate,
  authController.adminLogin
);

router.post('/refresh', csrfOriginCheck, authController.refresh);
router.post('/logout', csrfOriginCheck, authController.logout);

module.exports = router;
