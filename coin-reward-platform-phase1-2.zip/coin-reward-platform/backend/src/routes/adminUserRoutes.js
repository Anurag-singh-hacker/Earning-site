const express = require('express');
const { body, param, query } = require('express-validator');
const { authenticateAdmin } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate');
const adminUserController = require('../controllers/adminUserController');

const router = express.Router();

router.use(authenticateAdmin);

router.post(
  '/',
  [
    body('loginId')
      .trim()
      .isLength({ min: 3, max: 50 })
      .matches(/^[a-zA-Z0-9_.-]+$/)
      .withMessage('User ID may only contain letters, numbers, dot, underscore and hyphen'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
    body('fullName').trim().isLength({ min: 2, max: 100 }).withMessage('Full name is required'),
    body('email').optional({ checkFalsy: true }).isEmail().withMessage('Invalid email'),
    body('phone').optional({ checkFalsy: true }).isLength({ min: 7, max: 20 }),
    body('referredByCode').optional({ checkFalsy: true }).trim().isLength({ min: 4, max: 20 }),
  ],
  validate,
  adminUserController.createUser
);

router.get(
  '/',
  [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('status').optional().isIn(['pending', 'verified', 'rejected']),
    query('blocked').optional().isIn(['true', 'false']),
  ],
  validate,
  adminUserController.listUsers
);

router.get('/:id', [param('id').isInt()], validate, adminUserController.getUserById);

router.put(
  '/:id',
  [
    param('id').isInt(),
    body('fullName').optional().trim().isLength({ min: 2, max: 100 }),
    body('email').optional({ checkFalsy: true }).isEmail(),
    body('phone').optional({ checkFalsy: true }).isLength({ min: 7, max: 20 }),
  ],
  validate,
  adminUserController.updateUser
);

router.delete('/:id', [param('id').isInt()], validate, adminUserController.deleteUser);

router.patch('/:id/verify', [param('id').isInt()], validate, adminUserController.verifyUser);
router.patch('/:id/unverify', [param('id').isInt()], validate, adminUserController.unverifyUser);

router.patch(
  '/:id/block',
  [param('id').isInt(), body('reason').optional().trim().isLength({ max: 255 })],
  validate,
  adminUserController.blockUser
);

router.patch('/:id/unblock', [param('id').isInt()], validate, adminUserController.unblockUser);

router.post(
  '/:id/reset-password',
  [param('id').isInt(), body('newPassword').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')],
  validate,
  adminUserController.resetPassword
);

module.exports = router;
