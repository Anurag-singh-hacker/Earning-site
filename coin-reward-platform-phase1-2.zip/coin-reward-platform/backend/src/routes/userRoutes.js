const express = require('express');
const { authenticateUser } = require('../middleware/authMiddleware');
const userController = require('../controllers/userController');

const router = express.Router();

router.get('/me', authenticateUser, userController.getMyProfile);

module.exports = router;
