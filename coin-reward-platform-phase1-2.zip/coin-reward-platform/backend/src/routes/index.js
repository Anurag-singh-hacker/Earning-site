const express = require('express');
const authRoutes = require('./authRoutes');
const userRoutes = require('./userRoutes');
const adminUserRoutes = require('./adminUserRoutes');

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/user', userRoutes);
router.use('/admin/users', adminUserRoutes);

router.get('/health', (req, res) =>
  res.json({ success: true, data: { status: 'ok', time: new Date().toISOString() } })
);

module.exports = router;
