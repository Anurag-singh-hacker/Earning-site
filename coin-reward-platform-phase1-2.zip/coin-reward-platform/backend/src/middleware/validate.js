const { validationResult } = require('express-validator');

/**
 * Place after a chain of express-validator checks on a route.
 * Returns a uniform 422 response if any check failed.
 */
module.exports = function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      error: {
        message: 'Validation failed',
        fields: errors.array().map((e) => ({ field: e.path, message: e.msg })),
      },
    });
  }
  next();
};
