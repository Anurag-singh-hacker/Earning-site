const config = require('../config/env');

/**
 * Access tokens travel in the Authorization header, which browsers never
 * attach automatically — that alone makes most routes CSRF-resistant.
 * The refresh-token cookie is the one exception (it must be readable by
 * the browser automatically to work), so as defense-in-depth on top of
 * the SameSite=Strict cookie attribute, we also verify the request's
 * Origin/Referer matches an allowed frontend origin.
 */
function csrfOriginCheck(req, res, next) {
  const origin = req.get('origin') || req.get('referer');
  if (origin) {
    const isAllowed = config.corsOrigin.some((allowed) => origin.startsWith(allowed));
    if (!isAllowed) {
      return res.status(403).json({ success: false, error: { message: 'Invalid request origin' } });
    }
  }
  next();
}

module.exports = csrfOriginCheck;
