const rateLimit = require('express-rate-limit');

// Strict limiter for login endpoints — mitigates credential stuffing / brute force.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: { message: 'Too many login attempts. Please try again later.' } },
});

// Baseline limiter applied to the whole API as DoS mitigation.
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: { message: 'Too many requests. Please slow down.' } },
});

module.exports = { loginLimiter, apiLimiter };
