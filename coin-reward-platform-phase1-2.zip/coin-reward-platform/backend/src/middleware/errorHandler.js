const ApiError = require('../utils/ApiError');

// eslint-disable-next-line no-unused-vars
module.exports = function errorHandler(err, req, res, next) {
  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({
      success: false,
      error: { message: err.message, ...(err.fields ? { fields: err.fields } : {}) },
    });
  }

  // Common MySQL errors get a friendlier status than a raw 500
  if (err && err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ success: false, error: { message: 'This record already exists.' } });
  }

  console.error('[Unhandled Error]', err);
  const isProd = process.env.NODE_ENV === 'production';
  return res.status(500).json({
    success: false,
    error: { message: isProd ? 'Internal server error' : err.message },
  });
};
