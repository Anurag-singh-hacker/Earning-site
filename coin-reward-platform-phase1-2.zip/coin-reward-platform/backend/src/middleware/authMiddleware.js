const { verifyAccessToken } = require('../utils/jwt');
const { pool } = require('../config/db');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

function extractBearerToken(req) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) return null;
  return token;
}

/**
 * Verifies the access token AND re-checks the user's live status on
 * every request (blocked users are cut off immediately, not just
 * after their access token happens to expire).
 */
const authenticateUser = asyncHandler(async (req, res, next) => {
  const token = extractBearerToken(req);
  if (!token) throw new ApiError(401, 'Authentication required');

  let payload;
  try {
    payload = verifyAccessToken(token);
  } catch (err) {
    throw new ApiError(401, 'Invalid or expired token');
  }
  if (payload.role !== 'user') throw new ApiError(403, 'Forbidden');

  const [rows] = await pool.query(
    'SELECT id, login_id, full_name, verification_status, is_blocked FROM users WHERE id = ? LIMIT 1',
    [payload.sub]
  );
  if (rows.length === 0) throw new ApiError(401, 'Account no longer exists');
  if (rows[0].is_blocked) throw new ApiError(403, 'Your account has been blocked. Please contact support.');

  req.user = rows[0];
  next();
});

const authenticateAdmin = asyncHandler(async (req, res, next) => {
  const token = extractBearerToken(req);
  if (!token) throw new ApiError(401, 'Authentication required');

  let payload;
  try {
    payload = verifyAccessToken(token);
  } catch (err) {
    throw new ApiError(401, 'Invalid or expired token');
  }
  if (payload.role !== 'admin') throw new ApiError(403, 'Forbidden');

  const [rows] = await pool.query(
    'SELECT id, admin_login_id, name, role, is_active FROM admins WHERE id = ? LIMIT 1',
    [payload.sub]
  );
  if (rows.length === 0) throw new ApiError(401, 'Account no longer exists');
  if (!rows[0].is_active) throw new ApiError(403, 'This admin account has been disabled');

  req.admin = rows[0];
  next();
});

module.exports = { authenticateUser, authenticateAdmin };
