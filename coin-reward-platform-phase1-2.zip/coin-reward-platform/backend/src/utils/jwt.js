const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const config = require('../config/env');

/**
 * Short-lived signed access token. Sent in the `Authorization: Bearer`
 * header by the client and never stored server-side.
 */
function signAccessToken(payload) {
  return jwt.sign(payload, config.jwt.accessSecret, {
    expiresIn: config.jwt.accessExpiresIn,
  });
}

function verifyAccessToken(token) {
  return jwt.verify(token, config.jwt.accessSecret);
}

/**
 * Refresh tokens are deliberately NOT JWTs. They are high-entropy random
 * strings whose SHA-256 hash is stored in the `refresh_tokens` table.
 * This lets the server revoke a session instantly (logout, block,
 * password reset) instead of waiting for a self-contained JWT to expire.
 */
function generateRefreshToken() {
  return crypto.randomBytes(48).toString('hex');
}

function hashRefreshToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

module.exports = {
  signAccessToken,
  verifyAccessToken,
  generateRefreshToken,
  hashRefreshToken,
};
