/**
 * Writes one row to `audit_logs`. Call this for every sensitive
 * action (login, user creation, verification, blocking, coin/withdrawal
 * decisions, settings changes, etc).
 */
async function logAudit(
  db,
  { actorType, actorId = null, action, targetType = null, targetId = null, details = null, ipAddress = null }
) {
  await db.query(
    `INSERT INTO audit_logs (actor_type, actor_id, action, target_type, target_id, details, ip_address)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [actorType, actorId, action, targetType, targetId, details ? JSON.stringify(details) : null, ipAddress]
  );
}

module.exports = { logAudit };
