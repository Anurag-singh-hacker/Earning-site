/**
 * Throw this anywhere in a controller to produce a clean, predictable
 * JSON error response via the central errorHandler middleware.
 */
class ApiError extends Error {
  constructor(statusCode, message, fields = null) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.fields = fields;
  }
}

module.exports = ApiError;
