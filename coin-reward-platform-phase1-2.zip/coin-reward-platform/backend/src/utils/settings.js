/**
 * Reads a single setting from the `settings` key-value table.
 * `db` can be the pool or a transaction connection.
 */
async function getSetting(db, key, fallback = null) {
  const [rows] = await db.query('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1', [key]);
  if (rows.length === 0) return fallback;
  return rows[0].setting_value;
}

async function getNumberSetting(db, key, fallback) {
  const val = await getSetting(db, key, null);
  if (val === null) return fallback;
  const num = Number(val);
  return Number.isNaN(num) ? fallback : num;
}

module.exports = { getSetting, getNumberSetting };
