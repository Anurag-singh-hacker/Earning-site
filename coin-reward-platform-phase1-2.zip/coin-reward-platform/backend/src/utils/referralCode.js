const crypto = require('crypto');

// Excludes visually ambiguous characters: 0/O, 1/I/L
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

function randomCode(length = 8) {
  const bytes = crypto.randomBytes(length);
  let code = '';
  for (let i = 0; i < length; i++) {
    code += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return code;
}

/**
 * Generates an 8-character referral code guaranteed unique against the
 * `users.referral_code` column at generation time. `db` can be the pool
 * or a transaction connection (both share the same `.query()` API).
 */
async function generateUniqueReferralCode(db, maxAttempts = 10) {
  for (let i = 0; i < maxAttempts; i++) {
    const code = randomCode(8);
    const [rows] = await db.query('SELECT id FROM users WHERE referral_code = ? LIMIT 1', [code]);
    if (rows.length === 0) return code;
  }
  throw new Error('Could not generate a unique referral code, please retry.');
}

module.exports = { generateUniqueReferralCode };
