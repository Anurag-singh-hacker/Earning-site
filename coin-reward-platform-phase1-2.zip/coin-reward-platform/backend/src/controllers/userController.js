const { pool } = require('../config/db');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const ApiError = require('../utils/ApiError');

const getMyProfile = asyncHandler(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT id, login_id, full_name, email, phone, referral_code, verification_status, created_at
     FROM users WHERE id = ? LIMIT 1`,
    [req.user.id]
  );
  if (rows.length === 0) throw new ApiError(404, 'User not found');
  const user = rows[0];

  return success(res, {
    id: user.id,
    loginId: user.login_id,
    fullName: user.full_name,
    email: user.email,
    phone: user.phone,
    referralCode: user.referral_code,
    verificationStatus: user.verification_status,
    memberSince: user.created_at,
    verificationMessage:
      user.verification_status === 'pending'
        ? 'Your account is under admin verification. Please wait up to 24 hours.'
        : null,
  });
});

module.exports = { getMyProfile };
