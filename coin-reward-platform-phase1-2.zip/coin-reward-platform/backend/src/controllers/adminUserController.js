const { pool, withTransaction } = require('../config/db');
const { hashPassword } = require('../utils/password');
const { generateUniqueReferralCode } = require('../utils/referralCode');
const { getNumberSetting } = require('../utils/settings');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const ApiError = require('../utils/ApiError');
const { logAudit } = require('../utils/auditLog');

const createUser = asyncHandler(async (req, res) => {
  const { loginId, password, fullName, email, phone, referredByCode } = req.body;

  const [existing] = await pool.query('SELECT id FROM users WHERE login_id = ? LIMIT 1', [loginId]);
  if (existing.length > 0) throw new ApiError(409, 'This User ID is already taken');

  let referrer = null;
  if (referredByCode) {
    const [refRows] = await pool.query('SELECT id FROM users WHERE referral_code = ? LIMIT 1', [
      referredByCode.toUpperCase(),
    ]);
    if (refRows.length === 0) throw new ApiError(400, 'Referral code not found');
    referrer = refRows[0];
  }

  const passwordHash = await hashPassword(password);
  const referralCode = await generateUniqueReferralCode(pool);

  let newUser;
  try {
    newUser = await withTransaction(async (conn) => {
      const [result] = await conn.query(
        `INSERT INTO users (login_id, password_hash, full_name, email, phone, referral_code, referred_by, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [loginId, passwordHash, fullName, email || null, phone || null, referralCode, referrer ? referrer.id : null, req.admin.id]
      );
      const userId = result.insertId;

      await conn.query(
        `INSERT INTO wallets (user_id, total_coins, total_earnings_inr, total_withdrawn_inr) VALUES (?, 0, 0, 0)`,
        [userId]
      );

      if (referrer) {
        await conn.query(`INSERT INTO referrals (referrer_id, referred_id, status) VALUES (?, ?, 'pending')`, [
          referrer.id,
          userId,
        ]);
      }

      return { id: userId, loginId, fullName, referralCode, verificationStatus: 'pending' };
    });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      // Extremely rare: the referral_code collided under concurrent load. Retrying
      // the request generates a fresh code. loginId was already checked above.
      throw new ApiError(409, 'Could not create user due to a conflict, please try again');
    }
    throw err;
  }

  await logAudit(pool, {
    actorType: 'admin',
    actorId: req.admin.id,
    action: 'user_created',
    targetType: 'user',
    targetId: newUser.id,
    details: { loginId },
    ipAddress: req.ip,
  });

  return success(res, newUser, 201);
});

const listUsers = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
  const offset = (page - 1) * limit;

  const filters = [];
  const params = [];

  if (req.query.search) {
    filters.push('(login_id LIKE ? OR full_name LIKE ? OR email LIKE ? OR phone LIKE ?)');
    const term = `%${req.query.search}%`;
    params.push(term, term, term, term);
  }
  if (req.query.status && ['pending', 'verified', 'rejected'].includes(req.query.status)) {
    filters.push('verification_status = ?');
    params.push(req.query.status);
  }
  if (req.query.blocked === 'true' || req.query.blocked === 'false') {
    filters.push('is_blocked = ?');
    params.push(req.query.blocked === 'true' ? 1 : 0);
  }

  const whereClause = filters.length ? `WHERE ${filters.join(' AND ')}` : '';

  const [rows] = await pool.query(
    `SELECT id, login_id, full_name, email, phone, referral_code, verification_status, is_blocked, created_at, last_login_at
     FROM users ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );

  const [countRows] = await pool.query(`SELECT COUNT(*) AS total FROM users ${whereClause}`, params);
  const total = countRows[0].total;

  return success(res, {
    users: rows,
    pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
  });
});

const getUserById = asyncHandler(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT id, login_id, full_name, email, phone, referral_code, referred_by, verification_status,
            verified_at, is_blocked, blocked_reason, created_at, last_login_at
     FROM users WHERE id = ? LIMIT 1`,
    [req.params.id]
  );
  if (rows.length === 0) throw new ApiError(404, 'User not found');
  return success(res, rows[0]);
});

const updateUser = asyncHandler(async (req, res) => {
  const { fullName, email, phone } = req.body;
  const [existing] = await pool.query('SELECT id FROM users WHERE id = ? LIMIT 1', [req.params.id]);
  if (existing.length === 0) throw new ApiError(404, 'User not found');

  await pool.query(
    'UPDATE users SET full_name = COALESCE(?, full_name), email = COALESCE(?, email), phone = COALESCE(?, phone) WHERE id = ?',
    [fullName ?? null, email ?? null, phone ?? null, req.params.id]
  );

  await logAudit(pool, {
    actorType: 'admin',
    actorId: req.admin.id,
    action: 'user_updated',
    targetType: 'user',
    targetId: req.params.id,
    ipAddress: req.ip,
  });

  return success(res, { message: 'User updated successfully' });
});

const deleteUser = asyncHandler(async (req, res) => {
  const [existing] = await pool.query('SELECT id, login_id FROM users WHERE id = ? LIMIT 1', [req.params.id]);
  if (existing.length === 0) throw new ApiError(404, 'User not found');

  await pool.query('DELETE FROM users WHERE id = ?', [req.params.id]);

  await logAudit(pool, {
    actorType: 'admin',
    actorId: req.admin.id,
    action: 'user_deleted',
    targetType: 'user',
    targetId: req.params.id,
    details: { loginId: existing[0].login_id },
    ipAddress: req.ip,
  });

  return success(res, { message: 'User deleted successfully' });
});

const verifyUser = asyncHandler(async (req, res) => {
  const userId = req.params.id;

  const [userRows] = await pool.query('SELECT id, verification_status FROM users WHERE id = ? LIMIT 1', [userId]);
  if (userRows.length === 0) throw new ApiError(404, 'User not found');
  if (userRows[0].verification_status === 'verified') throw new ApiError(400, 'User is already verified');

  await withTransaction(async (conn) => {
    await conn.query(
      `UPDATE users SET verification_status = 'verified', verified_at = NOW(), verified_by = ? WHERE id = ?`,
      [req.admin.id, userId]
    );

    await conn.query(
      `INSERT INTO notifications (user_id, title, message, type)
       VALUES (?, 'Account Verified', 'Your account has been verified. Daily rewards and withdrawals are now active.', 'verification_approved')`,
      [userId]
    );

    // Pay out the referrer's reward, if this user was referred and it hasn't been paid yet.
    const [refRows] = await conn.query(
      `SELECT id, referrer_id FROM referrals WHERE referred_id = ? AND status = 'pending' LIMIT 1`,
      [userId]
    );

    if (refRows.length > 0) {
      const referral = refRows[0];
      const rewardCoins = await getNumberSetting(conn, 'referral_reward_coins', 10);
      const coinsPerRupee = await getNumberSetting(conn, 'coins_per_rupee', 10);
      const rewardInr = rewardCoins / coinsPerRupee;

      await conn.query(
        'UPDATE wallets SET total_coins = total_coins + ?, total_earnings_inr = total_earnings_inr + ? WHERE user_id = ?',
        [rewardCoins, rewardInr, referral.referrer_id]
      );

      const [walletRows] = await conn.query('SELECT total_coins FROM wallets WHERE user_id = ? LIMIT 1', [
        referral.referrer_id,
      ]);
      const balanceAfter = walletRows[0].total_coins;

      await conn.query(
        `INSERT INTO coin_history (user_id, change_amount, balance_after, reason, performed_by_admin_id, note)
         VALUES (?, ?, ?, 'referral_reward', ?, ?)`,
        [referral.referrer_id, rewardCoins, balanceAfter, req.admin.id, `Referral reward for verifying user #${userId}`]
      );

      await conn.query(
        `INSERT INTO reward_history (user_id, reward_type, coins, description, reference_id)
         VALUES (?, 'referral', ?, 'Referral reward', ?)`,
        [referral.referrer_id, rewardCoins, referral.id]
      );

      await conn.query(
        `UPDATE referrals SET status = 'completed', coins_awarded = ?, completed_at = NOW() WHERE id = ?`,
        [rewardCoins, referral.id]
      );

      await conn.query(
        `INSERT INTO notifications (user_id, title, message, type)
         VALUES (?, 'Referral Reward Received', ?, 'referral_reward')`,
        [referral.referrer_id, `You earned ${rewardCoins} coins for a successful referral!`]
      );
    }
  });

  await logAudit(pool, {
    actorType: 'admin',
    actorId: req.admin.id,
    action: 'user_verified',
    targetType: 'user',
    targetId: userId,
    ipAddress: req.ip,
  });

  return success(res, { message: 'User verified successfully' });
});

const unverifyUser = asyncHandler(async (req, res) => {
  const userId = req.params.id;
  const [existing] = await pool.query('SELECT id FROM users WHERE id = ? LIMIT 1', [userId]);
  if (existing.length === 0) throw new ApiError(404, 'User not found');

  await pool.query(`UPDATE users SET verification_status = 'pending', verified_at = NULL, verified_by = NULL WHERE id = ?`, [
    userId,
  ]);

  await logAudit(pool, {
    actorType: 'admin',
    actorId: req.admin.id,
    action: 'user_unverified',
    targetType: 'user',
    targetId: userId,
    ipAddress: req.ip,
  });

  return success(res, { message: 'User verification revoked' });
});

const blockUser = asyncHandler(async (req, res) => {
  const { reason } = req.body;
  const [existing] = await pool.query('SELECT id FROM users WHERE id = ? LIMIT 1', [req.params.id]);
  if (existing.length === 0) throw new ApiError(404, 'User not found');

  await pool.query('UPDATE users SET is_blocked = 1, blocked_reason = ? WHERE id = ?', [reason || null, req.params.id]);
  await pool.query(
    `UPDATE refresh_tokens SET revoked_at = NOW() WHERE owner_type = 'user' AND owner_id = ? AND revoked_at IS NULL`,
    [req.params.id]
  );

  await logAudit(pool, {
    actorType: 'admin',
    actorId: req.admin.id,
    action: 'user_blocked',
    targetType: 'user',
    targetId: req.params.id,
    details: { reason },
    ipAddress: req.ip,
  });

  return success(res, { message: 'User blocked successfully' });
});

const unblockUser = asyncHandler(async (req, res) => {
  const [existing] = await pool.query('SELECT id FROM users WHERE id = ? LIMIT 1', [req.params.id]);
  if (existing.length === 0) throw new ApiError(404, 'User not found');

  await pool.query('UPDATE users SET is_blocked = 0, blocked_reason = NULL WHERE id = ?', [req.params.id]);

  await logAudit(pool, {
    actorType: 'admin',
    actorId: req.admin.id,
    action: 'user_unblocked',
    targetType: 'user',
    targetId: req.params.id,
    ipAddress: req.ip,
  });

  return success(res, { message: 'User unblocked successfully' });
});

const resetPassword = asyncHandler(async (req, res) => {
  const { newPassword } = req.body;
  const [existing] = await pool.query('SELECT id FROM users WHERE id = ? LIMIT 1', [req.params.id]);
  if (existing.length === 0) throw new ApiError(404, 'User not found');

  const passwordHash = await hashPassword(newPassword);
  await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [passwordHash, req.params.id]);
  await pool.query(
    `UPDATE refresh_tokens SET revoked_at = NOW() WHERE owner_type = 'user' AND owner_id = ? AND revoked_at IS NULL`,
    [req.params.id]
  );

  await logAudit(pool, {
    actorType: 'admin',
    actorId: req.admin.id,
    action: 'user_password_reset',
    targetType: 'user',
    targetId: req.params.id,
    ipAddress: req.ip,
  });

  return success(res, { message: 'Password reset successfully' });
});

module.exports = {
  createUser,
  listUsers,
  getUserById,
  updateUser,
  deleteUser,
  verifyUser,
  unverifyUser,
  blockUser,
  unblockUser,
  resetPassword,
};
