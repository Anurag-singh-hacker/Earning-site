const { pool } = require('../config/db');
const { comparePassword } = require('../utils/password');
const { signAccessToken, generateRefreshToken, hashRefreshToken } = require('../utils/jwt');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/apiResponse');
const { logAudit } = require('../utils/auditLog');
const config = require('../config/env');

const REFRESH_COOKIE_NAME = 'refreshToken';
const REFRESH_COOKIE_PATH = '/api/auth';

function refreshCookieOptions() {
  return {
    httpOnly: true,
    secure: config.nodeEnv === 'production',
    sameSite: 'strict',
    path: REFRESH_COOKIE_PATH,
    maxAge: config.jwt.refreshExpiresDays * 24 * 60 * 60 * 1000,
  };
}

async function issueTokenPair({ ownerType, id, role, loginId, req, res }) {
  const accessToken = signAccessToken({ sub: id, role, loginId });

  const rawRefreshToken = generateRefreshToken();
  const tokenHash = hashRefreshToken(rawRefreshToken);
  const expiresAt = new Date(Date.now() + config.jwt.refreshExpiresDays * 24 * 60 * 60 * 1000);

  await pool.query(
    `INSERT INTO refresh_tokens (owner_type, owner_id, token_hash, user_agent, ip_address, expires_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [ownerType, id, tokenHash, req.get('user-agent') || null, req.ip, expiresAt]
  );

  res.cookie(REFRESH_COOKIE_NAME, rawRefreshToken, refreshCookieOptions());
  return accessToken;
}

const userLogin = asyncHandler(async (req, res) => {
  const { loginId, password } = req.body;

  const [rows] = await pool.query(
    'SELECT id, login_id, password_hash, full_name, verification_status, is_blocked FROM users WHERE login_id = ? LIMIT 1',
    [loginId]
  );

  if (rows.length === 0) throw new ApiError(401, 'Invalid User ID or password');
  const user = rows[0];

  if (user.is_blocked) throw new ApiError(403, 'Your account has been blocked. Please contact support.');

  const passwordMatches = await comparePassword(password, user.password_hash);
  if (!passwordMatches) throw new ApiError(401, 'Invalid User ID or password');

  const accessToken = await issueTokenPair({
    ownerType: 'user',
    id: user.id,
    role: 'user',
    loginId: user.login_id,
    req,
    res,
  });

  await pool.query('UPDATE users SET last_login_at = NOW() WHERE id = ?', [user.id]);
  await pool.query(
    `INSERT INTO notifications (user_id, title, message, type)
     VALUES (?, 'Login Successful', 'You have logged in successfully.', 'login')`,
    [user.id]
  );
  await logAudit(pool, { actorType: 'user', actorId: user.id, action: 'user_login', ipAddress: req.ip });

  return success(res, {
    accessToken,
    user: {
      id: user.id,
      loginId: user.login_id,
      fullName: user.full_name,
      verificationStatus: user.verification_status,
      verificationMessage:
        user.verification_status === 'pending'
          ? 'Your account is under admin verification. Please wait up to 24 hours.'
          : null,
    },
  });
});

const adminLogin = asyncHandler(async (req, res) => {
  const { loginId, password } = req.body;

  const [rows] = await pool.query(
    'SELECT id, admin_login_id, password_hash, name, role, is_active FROM admins WHERE admin_login_id = ? LIMIT 1',
    [loginId]
  );

  if (rows.length === 0) throw new ApiError(401, 'Invalid Admin ID or password');
  const admin = rows[0];

  if (!admin.is_active) throw new ApiError(403, 'This admin account has been disabled.');

  const passwordMatches = await comparePassword(password, admin.password_hash);
  if (!passwordMatches) throw new ApiError(401, 'Invalid Admin ID or password');

  const accessToken = await issueTokenPair({
    ownerType: 'admin',
    id: admin.id,
    role: 'admin',
    loginId: admin.admin_login_id,
    req,
    res,
  });

  await pool.query('UPDATE admins SET last_login_at = NOW() WHERE id = ?', [admin.id]);
  await logAudit(pool, { actorType: 'admin', actorId: admin.id, action: 'admin_login', ipAddress: req.ip });

  return success(res, {
    accessToken,
    admin: { id: admin.id, loginId: admin.admin_login_id, name: admin.name, role: admin.role },
  });
});

const refresh = asyncHandler(async (req, res) => {
  const rawToken = req.cookies?.[REFRESH_COOKIE_NAME];
  if (!rawToken) throw new ApiError(401, 'Refresh token missing');

  const tokenHash = hashRefreshToken(rawToken);
  const [rows] = await pool.query(
    'SELECT id, owner_type, owner_id, expires_at, revoked_at FROM refresh_tokens WHERE token_hash = ? LIMIT 1',
    [tokenHash]
  );

  if (rows.length === 0) throw new ApiError(401, 'Invalid refresh token');
  const record = rows[0];

  if (record.revoked_at || new Date(record.expires_at) < new Date()) {
    throw new ApiError(401, 'Session expired. Please log in again.');
  }

  // Rotate: revoke the presented token so it cannot be replayed, then issue a new pair.
  await pool.query('UPDATE refresh_tokens SET revoked_at = NOW() WHERE id = ?', [record.id]);

  let loginId, role;
  if (record.owner_type === 'user') {
    const [userRows] = await pool.query('SELECT login_id, is_blocked FROM users WHERE id = ? LIMIT 1', [
      record.owner_id,
    ]);
    if (userRows.length === 0 || userRows[0].is_blocked) throw new ApiError(401, 'Account unavailable');
    loginId = userRows[0].login_id;
    role = 'user';
  } else {
    const [adminRows] = await pool.query('SELECT admin_login_id, is_active FROM admins WHERE id = ? LIMIT 1', [
      record.owner_id,
    ]);
    if (adminRows.length === 0 || !adminRows[0].is_active) throw new ApiError(401, 'Account unavailable');
    loginId = adminRows[0].admin_login_id;
    role = 'admin';
  }

  const accessToken = await issueTokenPair({ ownerType: record.owner_type, id: record.owner_id, role, loginId, req, res });
  return success(res, { accessToken });
});

const logout = asyncHandler(async (req, res) => {
  const rawToken = req.cookies?.[REFRESH_COOKIE_NAME];
  if (rawToken) {
    const tokenHash = hashRefreshToken(rawToken);
    await pool.query('UPDATE refresh_tokens SET revoked_at = NOW() WHERE token_hash = ? AND revoked_at IS NULL', [
      tokenHash,
    ]);
  }
  res.clearCookie(REFRESH_COOKIE_NAME, { path: REFRESH_COOKIE_PATH });
  return success(res, { message: 'Logged out successfully' });
});

module.exports = { userLogin, adminLogin, refresh, logout };
