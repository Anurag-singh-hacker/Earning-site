/**
 * Bootstraps (or resets) the first admin account, since admins — like
 * users — have no public registration route.
 *
 * Usage:  npm run seed:admin
 * Reads SEED_ADMIN_LOGIN_ID / SEED_ADMIN_PASSWORD / SEED_ADMIN_NAME from .env
 */
require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');

async function main() {
  const loginId = process.env.SEED_ADMIN_LOGIN_ID;
  const password = process.env.SEED_ADMIN_PASSWORD;
  const name = process.env.SEED_ADMIN_NAME || 'Super Admin';

  if (!loginId || !password) {
    console.error('SEED_ADMIN_LOGIN_ID and SEED_ADMIN_PASSWORD must be set in your .env file.');
    process.exit(1);
  }
  if (password.length < 8) {
    console.error('SEED_ADMIN_PASSWORD must be at least 8 characters.');
    process.exit(1);
  }

  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
  });

  const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS || '12', 10);
  const passwordHash = await bcrypt.hash(password, saltRounds);

  const [existing] = await connection.query('SELECT id FROM admins WHERE admin_login_id = ? LIMIT 1', [loginId]);

  if (existing.length > 0) {
    await connection.query('UPDATE admins SET password_hash = ?, name = ?, is_active = 1 WHERE admin_login_id = ?', [
      passwordHash,
      name,
      loginId,
    ]);
    console.log(`Existing admin "${loginId}" updated.`);
  } else {
    await connection.query(
      'INSERT INTO admins (admin_login_id, name, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)',
      [loginId, name, passwordHash, 'super_admin']
    );
    console.log(`Admin "${loginId}" created successfully.`);
  }

  console.log('IMPORTANT: log in and change this password immediately if this is a fresh install.');
  await connection.end();
}

main().catch((err) => {
  console.error('Failed to seed admin account:', err);
  process.exit(1);
});
