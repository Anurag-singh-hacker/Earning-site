-- =========================================================
-- Coin Reward & Withdrawal Platform — Database Schema
-- Engine target: MySQL 8.0.16+ (needed for enforced CHECK constraints)
-- Charset: utf8mb4 / utf8mb4_unicode_ci throughout
-- =========================================================
-- Run with:  mysql -u root -p < schema.sql
-- This script assumes a FRESH database. It does not include
-- DROP TABLE statements to avoid accidental data loss.
-- =========================================================

CREATE DATABASE IF NOT EXISTS coin_reward_platform
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE coin_reward_platform;

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------
-- ADMINS
-- ---------------------------------------------------------
CREATE TABLE admins (
  id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_login_id    VARCHAR(50)  NOT NULL,
  name              VARCHAR(100) NOT NULL,
  password_hash     VARCHAR(255) NOT NULL,
  role              ENUM('super_admin','admin') NOT NULL DEFAULT 'admin',
  is_active         TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at     DATETIME NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_admins_login_id (admin_login_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- USERS  (created only by Admin — no public self-registration)
-- ---------------------------------------------------------
CREATE TABLE users (
  id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  login_id              VARCHAR(50)  NOT NULL,
  password_hash         VARCHAR(255) NOT NULL,
  full_name             VARCHAR(100) NOT NULL,
  email                 VARCHAR(150) NULL,
  phone                 VARCHAR(20)  NULL,
  referral_code         VARCHAR(20)  NOT NULL,
  referred_by           BIGINT UNSIGNED NULL,
  verification_status   ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  verified_at           DATETIME NULL,
  verified_by           BIGINT UNSIGNED NULL,
  is_blocked            TINYINT(1) NOT NULL DEFAULT 0,
  blocked_reason        VARCHAR(255) NULL,
  last_login_at         DATETIME NULL,
  created_by            BIGINT UNSIGNED NULL,
  created_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_login_id (login_id),
  UNIQUE KEY uq_users_referral_code (referral_code),
  KEY idx_users_verification_status (verification_status),
  KEY idx_users_referred_by (referred_by),
  CONSTRAINT fk_users_referred_by FOREIGN KEY (referred_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_users_verified_by FOREIGN KEY (verified_by) REFERENCES admins(id) ON DELETE SET NULL,
  CONSTRAINT fk_users_created_by  FOREIGN KEY (created_by)  REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- WALLETS  (1:1 with users — denormalized fast-read balances,
-- always mutated inside a transaction alongside coin_history)
-- ---------------------------------------------------------
CREATE TABLE wallets (
  id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id              BIGINT UNSIGNED NOT NULL,
  total_coins          BIGINT NOT NULL DEFAULT 0,
  total_earnings_inr   DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  total_withdrawn_inr  DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  updated_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_wallets_user_id (user_id),
  CONSTRAINT fk_wallets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT chk_wallets_total_coins_nonneg CHECK (total_coins >= 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- DAILY REWARDS  (idempotency log — one row per user per day,
-- so the daily cron can never double-credit)
-- ---------------------------------------------------------
CREATE TABLE daily_rewards (
  id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id        BIGINT UNSIGNED NOT NULL,
  reward_date    DATE NOT NULL,
  coins_awarded  INT UNSIGNED NOT NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_daily_rewards_user_date (user_id, reward_date),
  CONSTRAINT fk_daily_rewards_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- REWARD HISTORY  (every coin credit: daily / referral / admin bonus)
-- ---------------------------------------------------------
CREATE TABLE reward_history (
  id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id        BIGINT UNSIGNED NOT NULL,
  reward_type    ENUM('daily','referral','admin_bonus') NOT NULL,
  coins          INT NOT NULL,
  description    VARCHAR(255) NULL,
  reference_id   BIGINT UNSIGNED NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_reward_history_user (user_id, created_at),
  CONSTRAINT fk_reward_history_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- COIN HISTORY  (append-only ledger — every balance change, +/-)
-- ---------------------------------------------------------
CREATE TABLE coin_history (
  id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id                BIGINT UNSIGNED NOT NULL,
  change_amount          INT NOT NULL,
  balance_after          BIGINT NOT NULL,
  reason                 ENUM('daily_reward','referral_reward','withdrawal','withdrawal_refund',
                               'admin_add','admin_remove','admin_reset') NOT NULL,
  performed_by_admin_id  BIGINT UNSIGNED NULL,
  note                   VARCHAR(255) NULL,
  created_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_coin_history_user (user_id, created_at),
  CONSTRAINT fk_coin_history_user  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_coin_history_admin FOREIGN KEY (performed_by_admin_id) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- WITHDRAWALS
-- ---------------------------------------------------------
CREATE TABLE withdrawals (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id          BIGINT UNSIGNED NOT NULL,
  upi_id           VARCHAR(100) NOT NULL,
  amount_inr       DECIMAL(14,2) NOT NULL,
  coins_deducted   BIGINT NOT NULL,
  status           ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  admin_note       VARCHAR(255) NULL,
  processed_by     BIGINT UNSIGNED NULL,
  requested_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at     DATETIME NULL,
  KEY idx_withdrawals_user (user_id),
  KEY idx_withdrawals_status (status),
  CONSTRAINT fk_withdrawals_user  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_withdrawals_admin FOREIGN KEY (processed_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- REFERRALS
-- ---------------------------------------------------------
CREATE TABLE referrals (
  id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  referrer_id    BIGINT UNSIGNED NOT NULL,
  referred_id    BIGINT UNSIGNED NOT NULL,
  status         ENUM('pending','completed') NOT NULL DEFAULT 'pending',
  coins_awarded  INT UNSIGNED NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at   DATETIME NULL,
  UNIQUE KEY uq_referrals_referred (referred_id),
  KEY idx_referrals_referrer (referrer_id),
  CONSTRAINT fk_referrals_referrer FOREIGN KEY (referrer_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_referrals_referred FOREIGN KEY (referred_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT chk_referrals_no_self CHECK (referrer_id <> referred_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- SETTINGS  (key-value site configuration, admin editable)
-- ---------------------------------------------------------
CREATE TABLE settings (
  id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key    VARCHAR(100) NOT NULL,
  setting_value  TEXT NOT NULL,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  updated_by     BIGINT UNSIGNED NULL,
  UNIQUE KEY uq_settings_key (setting_key),
  CONSTRAINT fk_settings_admin FOREIGN KEY (updated_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- NOTIFICATIONS
-- ---------------------------------------------------------
CREATE TABLE notifications (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT UNSIGNED NULL,
  title       VARCHAR(150) NOT NULL,
  message     VARCHAR(500) NOT NULL,
  type        ENUM('login','verification_pending','verification_approved','daily_reward',
                    'withdrawal_submitted','withdrawal_approved','withdrawal_rejected',
                    'referral_reward','system') NOT NULL,
  is_read     TINYINT(1) NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_notifications_user (user_id, is_read),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- AUDIT LOGS  (every sensitive action, user/admin/system)
-- ---------------------------------------------------------
CREATE TABLE audit_logs (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_type   ENUM('user','admin','system') NOT NULL,
  actor_id     BIGINT UNSIGNED NULL,
  action       VARCHAR(100) NOT NULL,
  target_type  VARCHAR(50) NULL,
  target_id    BIGINT UNSIGNED NULL,
  details      JSON NULL,
  ip_address   VARCHAR(45) NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_audit_logs_actor (actor_type, actor_id),
  KEY idx_audit_logs_target (target_type, target_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- REFRESH TOKENS  (opaque, hashed, revocable sessions)
-- ---------------------------------------------------------
CREATE TABLE refresh_tokens (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_type   ENUM('user','admin') NOT NULL,
  owner_id     BIGINT UNSIGNED NOT NULL,
  token_hash   VARCHAR(255) NOT NULL,
  user_agent   VARCHAR(255) NULL,
  ip_address   VARCHAR(45) NULL,
  expires_at   DATETIME NOT NULL,
  revoked_at   DATETIME NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_refresh_tokens_owner (owner_type, owner_id),
  UNIQUE KEY uq_refresh_tokens_hash (token_hash)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------
-- DEFAULT SETTINGS
-- ---------------------------------------------------------
INSERT INTO settings (setting_key, setting_value) VALUES
  ('coins_per_rupee',        '10'),
  ('daily_reward_coins',     '30'),
  ('min_withdrawal_inr',     '100'),
  ('referral_reward_coins', '10'),
  ('site_name',              'CoinRewards'),
  ('site_logo_url',          ''),
  ('site_banner_url',        ''),
  ('notice_text',            ''),
  ('maintenance_mode',       'false');
