const app = require('./src/app');
const config = require('./src/config/env');

const server = app.listen(config.port, () => {
  console.log(`Coin Reward API listening on port ${config.port} [${config.nodeEnv}]`);
});

process.on('unhandledRejection', (err) => {
  console.error('Unhandled promise rejection:', err);
});

module.exports = server;
