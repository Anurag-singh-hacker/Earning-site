# Coin Reward & Withdrawal Platform

A coin-based reward, referral, and UPI withdrawal platform with an admin-controlled
user lifecycle (no public self-registration).

## Build status

This project is being delivered in phases so each layer is solid before the next
is built on top of it. **Phases 1 and 2 are complete** and included in this package.

- [x] **Phase 1 — Database schema** (`backend/database/schema.sql`, `docs/er-diagram.mermaid`)
- [x] **Phase 2 — Auth & User Management backend** (JWT auth, admin-created accounts,
      verification, block/unblock, password reset)
- [ ] Phase 3 — Wallet, daily reward cron, referral self-apply, withdrawal APIs
- [ ] Phase 4 — Admin panel APIs (coin management, withdrawal approvals, referral
      management, site settings) + frontend
- [ ] Phase 5 — User panel frontend
- [ ] Phase 6 — Security hardening pass, install/deploy docs, testing guide

Let me know when you'd like Phase 3 built.

## Folder structure

```
coin-reward-platform/
├── README.md
├── docs/
│   └── er-diagram.mermaid
└── backend/
    ├── package.json
    ├── .env.example
    ├── server.js
    ├── database/
    │   ├── schema.sql
    │   └── seed_admin.js
    └── src/
        ├── app.js
        ├── config/        # env loading, DB pool + transaction helper
        ├── utils/          # jwt, password hashing, referral codes, audit log, settings, responses
        ├── middleware/     # auth, rate limiting, validation, CSRF origin check, error handler
        ├── controllers/    # authController, userController, adminUserController
        └── routes/
```

## Getting started

1. **Create the database**
   ```
   mysql -u root -p < backend/database/schema.sql
   ```

2. **Configure environment**
   ```
   cd backend
   cp .env.example .env
   ```
   Fill in `DB_USER`, `DB_PASSWORD`, `DB_NAME`, and generate a long random value
   for `JWT_ACCESS_SECRET` (e.g. `openssl rand -hex 32`). Also set
   `SEED_ADMIN_LOGIN_ID` / `SEED_ADMIN_PASSWORD` for the first admin account.

3. **Install dependencies** (requires internet access on your machine)
   ```
   npm install
   ```

4. **Create the first admin account**
   ```
   npm run seed:admin
   ```

5. **Run the server**
   ```
   npm run dev
   ```
   The API listens on `http://localhost:5000/api` by default.

## Implemented endpoints (Phase 2)

**Auth**
- `POST /api/auth/user/login` — `{ loginId, password }`
- `POST /api/auth/admin/login` — `{ loginId, password }`
- `POST /api/auth/refresh` — rotates the refresh token (httpOnly cookie)
- `POST /api/auth/logout`

**User** (requires user access token)
- `GET /api/user/me` — profile, verification status, referral code

**Admin — User Management** (requires admin access token)
- `POST /api/admin/users` — create a user: `{ loginId, password, fullName, email?, phone?, referredByCode? }`
- `GET /api/admin/users?search=&status=&blocked=&page=&limit=` — search/list, paginated
- `GET /api/admin/users/:id`
- `PUT /api/admin/users/:id` — edit fullName/email/phone
- `DELETE /api/admin/users/:id`
- `PATCH /api/admin/users/:id/verify` — also pays out the referrer's coin reward, if applicable (see below)
- `PATCH /api/admin/users/:id/unverify`
- `PATCH /api/admin/users/:id/block` — `{ reason? }`, also revokes active sessions
- `PATCH /api/admin/users/:id/unblock`
- `POST /api/admin/users/:id/reset-password` — `{ newPassword }`, also revokes active sessions

Every endpoint returns `{ success: true, data }` or `{ success: false, error: { message, fields? } }`.

## Key design decisions & assumptions

- **Referral entry point.** The brief says users can't self-register, but also
  describes an "Enter Referral Code" box on the referral page. This build supports
  both: an admin can optionally attach `referredByCode` when creating a user, and
  Phase 3 will add a self-service "apply a referral code" endpoint for the user's
  first login (while still pending). Flag it if this doesn't match your intended
  flow — easy to adjust.
- **Referral payout timing.** The referrer's coins are credited only once the
  *referred* user is verified by an admin, exactly as specified — this is already
  wired into `PATCH /api/admin/users/:id/verify`, pulling the reward amount from
  `settings` (`referral_reward_coins`, `coins_per_rupee`) so it stays admin-configurable.
- **Refresh tokens** are opaque random strings (not JWTs), stored as a SHA-256 hash
  in `refresh_tokens`, delivered via an `httpOnly`, `Secure` (in production),
  `SameSite=Strict` cookie scoped to `/api/auth`. That makes them instantly
  revocable — logout, block, and password reset all revoke active sessions.
- **CSRF.** Access tokens travel in the `Authorization` header rather than a
  cookie, so most routes are naturally CSRF-resistant. The two cookie-based
  routes (`/refresh`, `/logout`) get an `Origin`/`Referer` allow-list check as
  defense in depth on top of `SameSite=Strict`.
- **SQL injection.** Every query uses parameterized placeholders via `mysql2`;
  nothing is string-concatenated.
- **Denormalized wallet totals.** `wallets.total_coins` / `total_earnings_inr` /
  `total_withdrawn_inr` are maintained transactionally alongside the append-only
  `coin_history` ledger, so dashboards stay fast without heavy aggregation — the
  ledger remains the source of truth if they ever need to be recomputed.
- **Audit trail.** Every admin action (create, verify, block, password reset, and
  the coin/withdrawal decisions coming in later phases) writes to `audit_logs`.
  For a program with a manual approval gate like this one, keeping that trail
  complete and the review turnaround fast is what keeps it trustworthy.
- Passwords are hashed with **bcrypt** (12 salt rounds by default, configurable).
- Not yet implemented: the daily reward cron, wallet/withdrawal endpoints, and
  admin coin/settings management — that's Phase 3.
